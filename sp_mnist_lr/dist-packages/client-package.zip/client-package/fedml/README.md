# Simple process of federate learning with mnist dataset and logistic regression
