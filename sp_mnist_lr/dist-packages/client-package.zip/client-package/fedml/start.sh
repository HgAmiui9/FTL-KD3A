export KMP_DUPLICATE_LIB_OK=TRUE

python main.py --cf ./config/fedml_config.yaml
